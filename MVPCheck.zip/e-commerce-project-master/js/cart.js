let cart = JSON.parse(localStorage.getItem('cart')) || [];

function updateCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
    console.log('Cart updated:', cart);
    const cartCountElement = document.querySelector('.header-cart-count');
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCountElement.textContent = totalItems;

}

function addToCart(quantity) {
    const product = {
        id: 1
    };
    const existingProductIndex = cart.findIndex(item => item.id === product.id);
    if (existingProductIndex !== -1) {
        cart[existingProductIndex].quantity += quantity;
    } else {
        cart.push(product);
    }
    updateCart();
    alert(`${quantity} Your vinyl was added to your cart!`);
}


document.getElementById('add-to-cart').addEventListener('click', function () {
    const quantityInput = document.getElementById('quantity');
    const quantity = parseInt(quantityInput.value);

    if (isNaN(quantity) || quantity < 1) {
        alert('Please enter a valid quantity.');
        return;
    }
    addToCart(quantity);
});
updateCart();
