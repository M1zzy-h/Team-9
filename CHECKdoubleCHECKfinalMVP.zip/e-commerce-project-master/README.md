# E-Commerce Project


Hi, this project is a fully responsive e-commerce website project made only HTML, CSS and JavaScript.

No framework or library (except glide.js) was used throughout the project.


You can reach the live link of the project from the link below.

Link : https://commerce-project.netlify.app/
